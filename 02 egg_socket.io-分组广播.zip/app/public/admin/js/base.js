$(function(){
	app.init();
})

var app={
	init:function(){
		this.toggleAside();
		this.deleteConfirm();
		this.resizeIframe();
		this.changeStatus();
	},
	toggleAside:function(){	
		$('.aside h4').click(function(){
			$(this).siblings('ul').slideToggle();
		})
	},
	deleteConfirm:function(){
		$('.delete').click(function(){
			var flag=confirm("您确定要删除吗?");
			return flag;
		});
	},
	resizeIframe:function(){
		// alert(document.documentElement.clientHeight);
		var height=document.documentElement.clientHeight-100;
		var rightMainDom=document.getElementById("rightMain");
		if(rightMainDom){
			rightMainDom.height=height;
		}	

	},
	changeStatus(){
		$(".chStatus").click(function(){
			var adminPath=$(this).attr("data-adminPath");
			var id=$(this).attr("data-id");
			var model=$(this).attr("data-model");
			var field=$(this).attr("data-field");
			var el=$(this).find("img");
			$.get("/"+adminPath+"/changeStatus",{"id":id,"model":model,"field":field},function(response){				
				if(response.success){
					if(el.attr("src").indexOf("yes")!=-1){
						el.attr("src","/public/admin/images/no.gif");
					}else{
						el.attr("src","/public/admin/images/yes.gif");
					}

				}
			})
		})
	}
}

$(window).resize(function(){
	app.resizeIframe();
})