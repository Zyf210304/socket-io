'use strict';
// Sequelize数据类型  http://bbs.itying.com/topic/60596c3b1bbeff13cc4cf0d6
module.exports = app => {
  const { STRING, INTEGER, DATE } = app.Sequelize;
  const Setting = app.model.define('setting', {
    id: { type: INTEGER, primaryKey: true, autoIncrement: true },
    title: STRING(255),
    siteLogo: STRING(255),
    siteKeywords: STRING(255),
    siteDescription: STRING(255),
    printerKey: STRING(255),
    printerUser: STRING(255),
    clientUrl: STRING(255),
    address: STRING(255),
    phone: STRING(255),
    wifiUser: STRING(255),
    wifiPassword: STRING(255),
    orderLabel: STRING(255),
    alipay: STRING(255),
    weixinpay: STRING(255)
  }, {
    timestamps: false, //自动增加创建时间 
    tableName: 'setting' //设置表名称
  });

  return Setting;
};