'use strict';
// Sequelize数据类型  http://bbs.itying.com/topic/60596c3b1bbeff13cc4cf0d6
module.exports = app => {
  const { STRING, INTEGER, DECIMAL } = app.Sequelize;
  const OrderItems = app.model.define('orderItems', {
    id: { type: INTEGER, primaryKey: true, autoIncrement: true },
    orderId:INTEGER(11),
    tableId:INTEGER(11),
    productId:INTEGER(11),
    productTitle:STRING(255),
    productImg:STRING(255),
    productPrice:DECIMAL(10,2),
    productNum:INTEGER(11),
    addTime:INTEGER(11),
    status:1    /*状态是1   表示已经下厨     状态是2表示退菜*/
  }, {
    timestamps: false, //自动增加创建时间 
    tableName: 'order_items' //设置表名称
  });

  return OrderItems;
};