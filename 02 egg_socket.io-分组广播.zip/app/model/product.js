// http://bbs.itying.com/topic/60596c3b1bbeff13cc4cf0d6

'use strict';
module.exports = app => {
  const { STRING, INTEGER, TEXT,DECIMAL } = app.Sequelize;
  const Product = app.model.define('Product', {
    id: { type: INTEGER, primaryKey: true, autoIncrement: true },
    cid:INTEGER(11),      
    title: STRING(255),
    price:DECIMAL(10, 2) ,
    imgUrl:STRING(255),
    content: TEXT,  
    saleCount: INTEGER(11),  
    isBest: INTEGER(1),  
    isHot: INTEGER(1),  
    status: INTEGER(1),  
    sort: INTEGER(11),
    addTime: INTEGER(11),
  },{
    timestamps: false, //自动增加创建时间 
    tableName: 'product' //设置表名称
  });  
  Product.associate = function (){ // 1 对 1 
    app.model.Product.belongsTo(app.model.ProductCate, {foreignKey: 'cid'});
  }
  return Product;
};