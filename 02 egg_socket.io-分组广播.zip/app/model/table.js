'use strict';
// Sequelize数据类型  http://bbs.itying.com/topic/60596c3b1bbeff13cc4cf0d6
module.exports = app => {
  const { STRING, INTEGER, DATE } = app.Sequelize;

  const Table = app.model.define('table', {
    id: { type: INTEGER, primaryKey: true, autoIncrement: true },
    title: STRING(255),
    tableNum: STRING(255),
    sort: INTEGER(11),  
    status: INTEGER(1),
    addTime: INTEGER(11)   
  },{
    timestamps: false, //自动增加创建时间 
    tableName: 'table' //设置表名称
  });

  return Table;
};