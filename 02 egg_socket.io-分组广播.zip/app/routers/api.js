'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller, config } = app;

  router.get(`/api/v1`, controller.api.v1.index); 
  router.post(`/api/v1/addCart`,app.jwt, controller.api.v1.addCart); 
  router.get(`/api/v1/productList`,app.jwt, controller.api.v1.productList); 
  router.get(`/api/v1/productContent`,app.jwt, controller.api.v1.productContent); 
    
  router.get('/api/v1/cartList',app.jwt, controller.api.v1.cartList); 
  router.post('/api/v1/addCart',app.jwt, controller.api.v1.addCart); 
  router.put('/api/v1/incCart',app.jwt, controller.api.v1.incCart); 
  router.put('/api/v1/decCart',app.jwt, controller.api.v1.decCart); 
  router.get('/api/v1/cartCount',app.jwt, controller.api.v1.cartCount); 

  router.get('/api/v1/flavorList',app.jwt, controller.api.v1.flavorList); 
  router.post('/api/v1/addPeopleInfo',app.jwt, controller.api.v1.addPeopleInfo); 
  router.get('/api/v1/getPeopleInfo',app.jwt, controller.api.v1.getPeopleInfo); 

  router.post('/api/v1/addOrder',app.jwt, controller.api.v1.addOrder); 
  router.get('/api/v1/getOrder',app.jwt, controller.api.v1.getOrder);

  router.get('/api/v1/login', controller.api.v1.login);
  
  
};
