'use strict';
var querystring = require("querystring");
const Controller = require('egg').Controller;

class DefaultController extends Controller {
  async index() {
    const { ctx, app } = this;
    const message = ctx.args[0];
    
    console.log("ClientMsg:",message);

    //广播给自己
    // await ctx.socket.emit('serverMsg', `Hi! I've got your message: ${message}`);

    //广播给所有人
    // await app.io.emit('serverMsg', `Hi! I've got your message: ${message}`);

    //分组广播
    let roomId = querystring.parse(ctx.socket.request.url.split("?")[1]).roomId;

    // app.io.to(roomId).emit("serverMsg","this is addCart msg");  //对房间（分组）内的用户广播消息

    ctx.socket.broadcast.to(roomId).emit('serverMsg','this is addCart msg');  //通知分组内的用户不包括自己
  }
}

module.exports = DefaultController;
