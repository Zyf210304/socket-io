'use strict';

const BaseController = require('./base.js');

class TableController extends BaseController {
    async index() {
        let result = await this.ctx.model.Table.findAll();
        await this.ctx.render("admin/table/index", {
            list: result
        })
    }
    async add() {
        await this.ctx.render("admin/table/add")
    }
    async doAdd() {
        let tableNum = this.ctx.request.body.tableNum;
        if (tableNum != "") {
            await this.ctx.model.Table.create(Object.assign(this.ctx.request.body, {
                status: 1,
                addTime: this.ctx.service.tools.getUnixTime()
            }))
            await this.success("增加桌号成功", `/${this.config.adminPath}/table`);
        } else {
            await this.error("桌号不能为空", `/${this.config.adminPath}/table/add`)
        }
    }

    async edit() {
        try {
            let id = this.ctx.request.query.id;
            let result = await this.ctx.model.Table.findAll({
                where: {
                    id: id
                }
            });
            await this.ctx.render("admin/table/edit", {
                list: result[0]
            });

        } catch (error) {
            await this.error("非法请求", `/${this.config.adminPath}/table`);
        }
    }
    async doEdit() {
        let id = this.ctx.request.body.id;
        let tableNum = this.ctx.request.body.tableNum;
        if (tableNum == "") {
            await this.error("桌号不能为空", `/${this.config.adminPath}/table/edit?id=${id}`);
            return;
        }

        let table = await this.ctx.model.Table.findByPk(id);
        if (!table) {
            await this.error("非法请求", `/${this.config.adminPath}/table/edit?id=${id}`);
            return;
        }
        await table.update(this.ctx.request.body);
        await this.success("修改数据成功", `/${this.config.adminPath}/table`);

    }
    async delete() {
        try {
            let id = this.ctx.request.query.id;
            let table = await this.ctx.model.Table.findByPk(id);
            if (!table) {
                await this.error("非法请求", `/${this.config.adminPath}/table/`);
                return;
            }
            await table.destroy();
            await this.success("删除数据成功", `/${this.config.adminPath}/table`);
        } catch (error) {
            await this.error("非法请求", `/${this.config.adminPath}/table`);
        }

    }
    async showCode() {
        // var qr_svg = qr.image('http://www.itying.com', { type: 'png' });        
        // this.ctx.type = 'image/png';
        // this.ctx.body=qr_svg;
        /*
            1、生成图形二维码   
            2、把二维码上传到对象存储   返回一个二维码的地址
            3、生成图片二维码 （合成图片）html5 canvas          
        */

        let id = this.ctx.request.query.id;
        let table = await this.ctx.model.Table.findByPk(id);

        let qrImage = await this.ctx.service.tools.getQrImage('http://www.itying.com?id=' + id);

        let qrImageObj = await this.ctx.service.tools.uploadCos("code_1.png", qrImage)

        await this.ctx.render("admin/table/code", {
            text: table.title,
            bgSrc: '/public/admin/images/bg.png',
            codeSrc: "http://" + qrImageObj.Location
        });


    }

}

module.exports = TableController;
