'use strict';
// Sequelize数据类型  http://bbs.itying.com/topic/60596c3b1bbeff13cc4cf0d6
module.exports = app => {
  const { STRING, INTEGER, DECIMAL } = app.Sequelize;
  const Cart = app.model.define('cart', {
    id: { type: INTEGER, primaryKey: true, autoIncrement: true },
    tableId:INTEGER(11), 
    productTitle: STRING(255),
    imgUrl:STRING(255),
    productPrice:DECIMAL(10, 2),
    productNum: INTEGER(11),  
    productId: INTEGER(11), 
    addTime: INTEGER(11)    
  }, {
    timestamps: false, //自动增加创建时间 
    tableName: 'cart' //设置表名称
  });

  return Cart;
};