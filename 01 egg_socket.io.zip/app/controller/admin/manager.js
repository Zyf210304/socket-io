'use strict';

const BaseController = require('./base.js');

class ManagerController extends BaseController {
  async index() {
    let result = await this.ctx.model.Admin.findAll({
      include: { model: this.ctx.model.Role }
    });
    console.log(result[1].role.title);
    await this.ctx.render("admin/manager/index", {
      list: result
    })
  }
  async add() {
    //获取角色
    let roleList = await this.ctx.model.Role.findAll();
    await this.ctx.render("admin/manager/add", {
      roleList: roleList
    })
  }
  async doAdd() {
    //1、获取表单穿过来的数据
    let addResult = this.ctx.request.body;
    //2、验证数据是否合成  前端js  后端验证
    if (addResult.username == "") {
      await this.error("管理员名称不能为空", `/${this.config.adminPath}/manager/add`);
      return;
    }
    if (addResult.password.length < 6) {
      await this.error("管理员的密码不能小于6位", `/${this.config.adminPath}/manager/add`);
      return;
    }
    //3、数据库表里面有没有当前用户
    let adminResult = await this.ctx.model.Admin.findAll({
      where: {
        username: addResult.username
      }
    })
    if (adminResult.length > 0) {
      await this.error("此管理员已经存在", `/${this.config.adminPath}/manager/add`);
    } else {
      addResult.password = this.ctx.service.tools.md5(addResult.password);
      await this.ctx.model.Admin.create({
        ...addResult,
        ...{
          addTime: this.ctx.service.tools.getUnixTime(),
          status: 1,
          isSuper: 0
        }
      })
      await this.success("增加管理员成功", `/${this.config.adminPath}/manager`);
    }


  }
  async edit() {
    //1、获取当前编辑的管理
    let id = this.ctx.request.query.id;
    let managerResult = await this.ctx.model.Admin.findAll({
      where: {
        id: id
      }
    })

    //2、获取所有的角色
    let roleList = await this.ctx.model.Role.findAll();

    await this.ctx.render("admin/manager/edit", {
      manager: managerResult[0],
      roleList: roleList
    })
  }
  async doEdit() {
    //1、获取表单传过来的数据
    let editResult = this.ctx.request.body;
    //2、判断密码是否为空
    if (editResult.password != "") {
      if (editResult.password.length < 6) {
        await this.error("管理员的密码不能小于6位", `/${this.config.adminPath}/manager/edit?id=${editResult.id}`);
        return;
      }
      editResult.password = this.ctx.service.tools.md5(editResult.password);
    } else {
      delete editResult.password;
    }

    let managerResult = await this.ctx.model.Admin.findByPk(editResult.id);
    await managerResult.update(editResult);
    await this.success("管理员修改成功", `/${this.config.adminPath}/manager`);

  }
  async delete() {
    try {
      let id = this.ctx.request.query.id;
      let managerResult = await this.ctx.model.Admin.findByPk(id);
      if (!managerResult) {
        await this.error("非法请求",`/${this.config.adminPath}/manager/`);
        return;
       }
      managerResult.destroy();
      await this.success("删除数据成功", `/${this.config.adminPath}/manager`);
    } catch (error) {
      await this.error("非法请求", `/${this.config.adminPath}/role`);
    }
  }
}
module.exports = ManagerController;
