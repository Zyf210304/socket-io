module.exports = app => {
    return async (ctx, next) => {
        console.log("连接成功...")
        ctx.socket.emit('serverMsg', 'connected success');
        await next(); 
    };
};